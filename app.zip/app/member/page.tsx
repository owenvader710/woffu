import { redirect } from "next/navigation";

export default function MemberRedirect() {
  redirect("/members");
}
