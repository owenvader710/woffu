"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import CreateProjectModal from "./CreateProjectModal";

type Project = {
  id: string;
  title: string;
  type: "VIDEO" | "GRAPHIC";
  status: "TODO" | "IN_PROGRESS" | "BLOCKED" | "COMPLETED";
  created_at: string;
  start_date: string | null;
  due_date: string | null;

  brand?: string | null;
  video_priority?: string | null; // "2" | "3" | "5" | "SPECIAL"
  video_purpose?: string | null;
  graphic_job_type?: string | null;
};

type Member = {
  id: string;
  display_name: string | null;
  department: "VIDEO" | "GRAPHIC" | "ALL";
  role: "LEADER" | "MEMBER";
  is_active: boolean;
  phone?: string | null;
  avatar_url?: string | null;
};

async function safeJson(res: Response) {
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

function formatDateTH(iso?: string | null) {
  if (!iso) return "-";
  const d = new Date(iso);
  return d.toLocaleDateString("th-TH", { year: "numeric", month: "short", day: "2-digit" });
}

const STATUSES: Project["status"][] = ["TODO", "IN_PROGRESS", "BLOCKED", "COMPLETED"];
type StatusFilter = Project["status"] | "ALL";
type DeptFilter = "ALL" | "VIDEO" | "GRAPHIC";

function statusLabel(s: StatusFilter) {
  if (s === "ALL") return "ทั้งหมด";
  return s;
}

function deptLabel(d: DeptFilter) {
  if (d === "ALL") return "ทุกฝ่าย";
  return d;
}

function secondLine(p: Project) {
  const brand = p.brand ? `แบรนด์: ${p.brand}` : null;

  const videoBits =
    p.type === "VIDEO"
      ? [
          p.video_priority
            ? `ความสำคัญ: ${p.video_priority === "SPECIAL" ? "SPECIAL" : `${p.video_priority} ดาว`}`
            : null,
          p.video_purpose ? `รูปแบบ: ${p.video_purpose}` : null,
        ].filter(Boolean)
      : [];

  const graphicBits =
    p.type === "GRAPHIC"
      ? [p.graphic_job_type ? `ประเภทงาน: ${p.graphic_job_type}` : null].filter(Boolean)
      : [];

  const all = [brand, ...videoBits, ...graphicBits].filter(Boolean);
  return all.length ? all.join(" · ") : "";
}

function normalize(s: string) {
  return s.trim().toLowerCase();
}

export default function ProjectsPage() {
  const [items, setItems] = useState<Project[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [open, setOpen] = useState(false);

  // role (แสดงปุ่มสั่งงานใหม่เฉพาะหัวหน้า)
  const [meRole, setMeRole] = useState<"LEADER" | "MEMBER" | null>(null);
  const isLeader = meRole === "LEADER";

  // ✅ ข้อ 1: status filter
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("ALL");

  // ✅ ข้อ 2: department filter
  const [deptFilter, setDeptFilter] = useState<DeptFilter>("ALL");

  // ✅ ข้อ 3: search
  const [q, setQ] = useState("");

  async function loadMe() {
    try {
      const res = await fetch("/api/me", { cache: "no-store" });
      const json = await safeJson(res);
      if (!res.ok) return setMeRole(null);

      const role =
        json?.data?.profile?.role ??
        json?.data?.role ??
        json?.profile?.role ??
        json?.role ??
        null;

      setMeRole(role);
    } catch {
      setMeRole(null);
    }
  }

  async function loadProjects() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/projects", { cache: "no-store" });
      const json = await safeJson(res);

      if (!res.ok) {
        setItems([]);
        setError((json && (json.error || json.message)) || `Load projects failed (${res.status})`);
        return;
      }

      const data = Array.isArray(json?.data) ? json.data : Array.isArray(json) ? json : [];
      setItems(data);
    } catch (e: any) {
      setItems([]);
      setError(e?.message || "Load projects failed");
    } finally {
      setLoading(false);
    }
  }

  async function loadMembers() {
    const tryUrls = ["/api/members", "/api/profiles"];
    for (const url of tryUrls) {
      try {
        const res = await fetch(url, { cache: "no-store" });
        const json = await safeJson(res);
        if (!res.ok) continue;

        const data = Array.isArray(json?.data) ? json.data : Array.isArray(json) ? json : null;
        if (Array.isArray(data)) {
          const actives = data.filter((m: Member) => m.is_active !== false);
          setMembers(actives);
          return;
        }
      } catch {}
    }
    setMembers([]);
  }

  useEffect(() => {
    loadMe();
    loadProjects();
    loadMembers();
  }, []);

  // 1) filter ฝ่ายก่อน
  const deptFiltered = useMemo(() => {
    if (deptFilter === "ALL") return items;
    return items.filter((p) => p.type === deptFilter);
  }, [items, deptFilter]);

  // 2) search ต่อจากฝ่าย
  const searched = useMemo(() => {
    const query = normalize(q);
    if (!query) return deptFiltered;

    return deptFiltered.filter((p) => {
      const hay = [
        p.title,
        p.brand ?? "",
        p.video_priority ?? "",
        p.video_purpose ?? "",
        p.graphic_job_type ?? "",
        p.status,
        p.type,
      ]
        .join(" ")
        .toLowerCase();
      return hay.includes(query);
    });
  }, [deptFiltered, q]);

  // 3) counts สถานะ (อิงจาก ฝ่าย + search เพื่อให้ tab count ตรงกับที่เห็น)
  const counts = useMemo(() => {
    const base = { ALL: searched.length, TODO: 0, IN_PROGRESS: 0, BLOCKED: 0, COMPLETED: 0 } as Record<
      StatusFilter,
      number
    >;
    for (const p of searched) base[p.status] += 1;
    return base;
  }, [searched]);

  // 4) status filter เป็นขั้นสุดท้าย
  const filteredItems = useMemo(() => {
    if (statusFilter === "ALL") return searched;
    return searched.filter((p) => p.status === statusFilter);
  }, [searched, statusFilter]);

  return (
    <div className="p-10">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">โปรเจกต์ทั้งหมด</h1>
          <p className="mt-1 text-sm text-gray-600">รายการทั้งหมด: {items.length}</p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => {
              loadMe();
              loadProjects();
              loadMembers();
            }}
            className="rounded-xl border px-4 py-2 text-sm hover:bg-gray-50"
          >
            รีเฟรช
          </button>

          {isLeader && (
            <button
              onClick={() => setOpen(true)}
              className="rounded-xl bg-lime-300 px-4 py-2 text-sm font-medium hover:opacity-90"
            >
              + สั่งงานใหม่
            </button>
          )}
        </div>
      </div>

      {/* ✅ ข้อ 1: Tabs สถานะ */}
      <div className="mt-6 flex flex-wrap gap-2">
        {(["ALL", ...STATUSES] as const).map((s) => {
          const active = statusFilter === s;
          return (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`rounded-xl border px-3 py-2 text-xs hover:bg-gray-50 ${
                active ? "bg-black text-white hover:bg-black" : ""
              }`}
            >
              {statusLabel(s)}{" "}
              <span className={active ? "opacity-90" : "text-gray-500"}>({counts[s] ?? 0})</span>
            </button>
          );
        })}
      </div>

      {/* ✅ ข้อ 2: Tabs ฝ่าย + ✅ ข้อ 3: Search */}
      <div className="mt-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-2">
          {(["ALL", "VIDEO", "GRAPHIC"] as const).map((d) => {
            const active = deptFilter === d;
            return (
              <button
                key={d}
                onClick={() => setDeptFilter(d)}
                className={`rounded-xl border px-3 py-2 text-xs hover:bg-gray-50 ${
                  active ? "bg-black text-white hover:bg-black" : ""
                }`}
              >
                {deptLabel(d)}
              </button>
            );
          })}
        </div>

        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="w-full md:w-[420px] rounded-xl border px-4 py-2 text-sm"
          placeholder="ค้นหา: ชื่อโปรเจกต์ / แบรนด์ / รูปแบบงาน / ประเภทงาน"
        />
      </div>

      {loading && <div className="mt-6 rounded-xl border p-4 text-sm text-gray-600">กำลังโหลด...</div>}

      {!loading && error && (
        <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {!loading && !error && (
        <div className="mt-6 overflow-hidden rounded-2xl border">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="text-left">
                <th className="p-4">โปรเจกต์</th>
                <th className="p-4">ฝ่าย</th>
                <th className="p-4">สถานะ</th>
                <th className="p-4">วันที่สั่ง</th>
                <th className="p-4">Deadline</th>
              </tr>
            </thead>

            <tbody>
              {filteredItems.length === 0 ? (
                <tr>
                  <td className="p-6 text-gray-400" colSpan={5}>
                    ไม่มีรายการที่ตรงกับตัวกรอง/คำค้นหา
                  </td>
                </tr>
              ) : (
                filteredItems.map((p) => (
                  <tr key={p.id} className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <Link className="underline" href={`/projects/${p.id}`}>
                        {p.title}
                      </Link>
                      {secondLine(p) ? <div className="mt-1 text-xs text-gray-500">{secondLine(p)}</div> : null}
                    </td>
                    <td className="p-4">{p.type}</td>
                    <td className="p-4">{p.status}</td>
                    <td className="p-4">{formatDateTH(p.created_at)}</td>
                    <td className="p-4">{formatDateTH(p.due_date)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      <CreateProjectModal
        open={open}
        onClose={() => setOpen(false)}
        members={members}
        onCreated={async () => {
          setOpen(false);
          await loadProjects();
        }}
      />
    </div>
  );
}