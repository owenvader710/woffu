import { NextRequest, NextResponse } from "next/server";
import { supabaseFromRequest } from "@/utils/supabase/api";

function isUuid(v: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(v);
}

async function unwrapParams(ctx: any) {
  const p = ctx?.params;
  if (!p) return null;
  if (typeof p?.then === "function") return await p;
  return p;
}

function extractProjectId(req: NextRequest, paramsObj: any) {
  const fromParams = paramsObj?.id;
  if (fromParams) return fromParams;

  const path = req.nextUrl.pathname;
  const m = path.match(/\/api\/projects\/([^/]+)\/?$/);
  return m?.[1] ?? null;
}

/**
 * ✅ Hard delete project (Leader only)
 * - ลบตารางลูกก่อน เพื่อไม่ให้ติด foreign key
 * - แล้วค่อยลบ projects
 *
 * IMPORTANT:
 * ชื่อ table ลูกของนายท่านอาจต่างกัน ให้แก้ค่าด้านล่างให้ตรงกับ DB จริง
 */
const CHILD_TABLES = [
  // 👇 ปรับให้ตรงกับของจริงใน Supabase
  { table: "project_status_requests", fk: "project_id" },
  { table: "project_logs", fk: "project_id" },
];

export async function DELETE(req: NextRequest, ctx: any) {
  try {
    const paramsObj = await unwrapParams(ctx);
    const projectId = extractProjectId(req, paramsObj);

    if (!projectId) return NextResponse.json({ error: "Missing project id (params.id)" }, { status: 400 });
    if (!isUuid(projectId)) return NextResponse.json({ error: `Invalid project id: ${projectId}` }, { status: 400 });

    const { supabase, applyCookies } = supabaseFromRequest(req);

    // auth
    const { data: authData, error: authErr } = await supabase.auth.getUser();
    if (authErr) return NextResponse.json({ error: authErr.message }, { status: 401 });
    if (!authData?.user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });

    // ✅ เช็คหัวหน้า (LEADER + active) จาก profiles
    const { data: me, error: meErr } = await supabase
      .from("profiles")
      .select("role, is_active")
      .eq("id", authData.user.id)
      .single();

    if (meErr) {
      const res = NextResponse.json({ error: meErr.message }, { status: 400 });
      return applyCookies(res);
    }
    if (!(me?.role === "LEADER" && me?.is_active === true)) {
      const res = NextResponse.json({ error: "เฉพาะหัวหน้าเท่านั้น" }, { status: 403 });
      return applyCookies(res);
    }

    // ✅ ลบจริงผ่าน function
    const { error: delErr } = await supabase.rpc("delete_project_hard", { p_project_id: projectId });
    if (delErr) {
      const res = NextResponse.json({ error: delErr.message }, { status: 400 });
      return applyCookies(res);
    }

    const res = NextResponse.json({ ok: true }, { status: 200 });
    return applyCookies(res);
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? "Internal error" }, { status: 500 });
  }
}